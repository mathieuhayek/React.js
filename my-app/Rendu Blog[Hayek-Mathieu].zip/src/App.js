import React, { Component } from 'react';
import './App.css';
import Login from './components/Log/Login'

class App extends Component {

  render(){

    return (
        <Login></Login>
    );
  }
}

export default App;

